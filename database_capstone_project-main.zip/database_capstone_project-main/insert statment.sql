insert into booking(BookingID,BookingDate,TableNo,GuestID,Bookingslot,Employee) values
(1,'2022-10-10',1,1,'18:00:00',1),
(2,'2022-11-12',4,3,'18:00:00',3),
(3,'2022-10-11',5,2,'19:00:00',3),
(4,'2022-10-11',3,4,'20:00:00',5),
(5,'2022-10-13',6,5,'20:00:00',4)

select * from booking